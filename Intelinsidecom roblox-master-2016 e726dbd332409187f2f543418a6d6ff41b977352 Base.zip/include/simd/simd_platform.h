#pragma once

#include <boost/cstdint.hpp>
#include <boost/static_assert.hpp>
#include <stdint.h>

#if defined( __i386__ ) || defined( _M_IX86 ) // __i386__ on clang, _M_IX86 on MVC
#define RBX_SIMD_X86 
#endif

#if defined( __x86_64__ ) || defined( _M_X64 ) // __x86_64__ on clang, _M_X64 on MVC
#define RBX_SIMD_X64
#endif

#if defined( __ARM_NEON ) || defined( __arm__ ) || defined( _M_ARM ) || defined( _M_ARM64 ) 
#define RBX_SIMD_ARM
#endif

// __PPC__/_M_PPC/_PPC_/X360__ are set by the Xbox 360 compiler configuration
#if defined( __PPC__ ) || defined( _M_PPC ) || defined( _PPC_ ) || defined( X360__ )
#define RBX_SIMD_PPC
#endif

#if defined( RBX_SIMD_X86 ) || defined( RBX_SIMD_X64 )
#define RBX_SIMD_USE_SSE
#elif defined( RBX_SIMD_ARM )
#define RBX_SIMD_USE_NEON
#elif defined( RBX_SIMD_PPC )
#define RBX_SIMD_USE_VMX
#endif

#if defined(RBX_SIMD_USE_SSE) && !defined(_M_ARM) && !defined(_M_ARM64)
#include <xmmintrin.h>
#include <emmintrin.h>
#include <mmintrin.h>
#endif

#ifdef RBX_SIMD_USE_NEON
#include <arm_neon.h>
#endif

#ifdef RBX_SIMD_USE_VMX
#include <ppcintrinsics.h>
#endif

#define RBX_SIMD_ALIGN_ASSERT( p, a ) RBXASSERT_VERY_FAST( ( ( uint64_t )( p ) & ( a - 1 ) ) == 0 )

#ifdef _MSC_VER
#define RBX_SIMD_INLINE __forceinline
#elif defined( __clang__ ) || defined( __GNUC__ )
#define RBX_SIMD_INLINE inline __attribute__((always_inline))
#else
#define RBX_SIMD_INLINE inline
#endif

namespace RBX
{

namespace simd
{

namespace details
{
#if defined( RBX_SIMD_USE_SSE )
    typedef __m128 vec4f_t;
    typedef __m128i vec4i_t;
    typedef __m128i vec4u_t;
#elif defined( RBX_SIMD_USE_NEON )
    typedef float32x4_t vec4f_t;
    typedef int32x4_t vec4i_t;
    typedef uint32x4_t vec4u_t;
#elif defined( RBX_SIMD_USE_VMX )
    // Xbox 360 VMX/VMX128: one 128-bit type for all three lanes types
    typedef __vector4 vec4f_t;
    typedef __vector4 vec4i_t;
    typedef __vector4 vec4u_t;
#endif

template< class ScalarType >
struct VectorTypeSelect;

template< >
struct VectorTypeSelect< float >
{
    typedef vec4f_t type;
};

template< >
struct VectorTypeSelect< int32_t >
{
    typedef vec4i_t type;
};

template< >
struct VectorTypeSelect< uint32_t >
{
    typedef vec4u_t type;
};

}

}

}
