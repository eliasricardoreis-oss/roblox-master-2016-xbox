//  GetCurrentProcess.hpp  --------------------------------------------------------------//

//  Copyright 2010 Vicente J. Botet Escriba

//  Distributed under the Boost Software License, Version 1.0.
//  See http://www.boost.org/LICENSE_1_0.txt


#ifndef BOOST_DETAIL_WINAPI_GETCURRENTPROCESS_HPP
#define BOOST_DETAIL_WINAPI_GETCURRENTPROCESS_HPP

#include <boost/detail/winapi/basic_types.hpp>

#if defined( RBX_PLATFORM_XBOX360 )
#include <windows.h>
#endif

#ifdef BOOST_HAS_PRAGMA_ONCE
#pragma once
#endif

namespace boost {
namespace detail {
namespace winapi {
#if defined( RBX_PLATFORM_XBOX360 )
#undef GetCurrentProcess
inline HANDLE_ GetCurrentProcess()
{
  return (HANDLE_) -1;
}
#elif defined( BOOST_USE_WINDOWS_H )
    using ::GetCurrentProcess;
#else
    extern "C" __declspec(dllimport) HANDLE_ WINAPI GetCurrentProcess();
#endif
}
}
}
#endif // BOOST_DETAIL_WINAPI_GETCURRENTPROCESS_HPP
