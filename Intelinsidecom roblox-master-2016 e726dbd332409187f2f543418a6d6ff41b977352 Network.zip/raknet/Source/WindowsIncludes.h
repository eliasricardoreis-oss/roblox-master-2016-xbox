#if defined(X360__) 
#include <windows.h>
#include <winsockx.h>
#elif defined (_WIN32)
#if defined(RBX_PLATFORM_UWP)
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0A00
#endif
#else
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0501
#endif
#endif
#if defined(WINAPI_FAMILY) && (WINAPI_FAMILY == WINAPI_FAMILY_PHONE_APP)
#undef _WIN32_WINNT
#define _WIN32_WINNT 0x0602
#endif
#include <WinSock2.h>
#include <windows.h>
#if !defined(RBX_PLATFORM_WIN_PHONE)
#include <Ws2tcpip.h>
#endif

// Must always include Winsock2.h before windows.h
// or else:
// winsock2.h(99) : error C2011: 'fd_set' : 'struct' type redefinition
// winsock2.h(134) : warning C4005: 'FD_SET' : macro redefinition
// winsock.h(83) : see previous definition of 'FD_SET'
// winsock2.h(143) : error C2011: 'timeval' : 'struct' type redefinition
// winsock2.h(199) : error C2011: 'hostent' : 'struct' type redefinition
// winsock2.h(212) : error C2011: 'netent' : 'struct' type redefinition
// winsock2.h(219) : error C2011: 'servent' : 'struct' type redefinition 

#endif
